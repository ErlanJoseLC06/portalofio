<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restaurante S.A</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php
    // Función para mostrar el menú y procesar la selección del usuario
    function mostrarMenu($titulo, $opciones) {
        echo "<h2 class='subtitulo'>$titulo</h2>";
        echo "<form method='post' class='table__meals'>";
        echo "<table class='meals'>";
        echo "<tr><th>Seleccionar</th><th>Nombre</th><th>Precio</th></tr>";
        foreach ($opciones as $codigo => $opcion) {
            echo "<tr>";
            echo "<td><input type='checkbox' name='seleccionados[$codigo]' value='{$opcion['nombre']}'></td>";
            echo "<td>{$opcion['nombre']}</td>";
            echo "<td>S/. {$opcion['precio']}</td>";
            echo "</tr>";
        }
        echo "</table>";
        echo "<br>";
    }
    

    // Definir las opciones de cada menú
    $desayunoOpciones = [
        '1' => ['nombre' => 'Café', 'precio' => 4.50],
        '2' => ['nombre' => 'Chocolate', 'precio' => 5.00],
        '3' => ['nombre' => 'Avena', 'precio' => 4.00],
        '4' => ['nombre' => 'Capuchino', 'precio' => 7.00],
        '5' => ['nombre' => 'Té', 'precio' => 3.50],
        '6' => ['nombre' => 'Jugo de Papaya', 'precio' => 6.00],
        '7' => ['nombre' => 'Jugo de Piña', 'precio' => 5.00],
        '8' => ['nombre' => 'Jugo de Fresa', 'precio' => 5.50],
        '9' => ['nombre' => 'Jugo de Mango', 'precio' => 5.00],
        '10' => ['nombre' => 'Jugo de Platano', 'precio' => 5.00]
    ];

    $almuerzoOpciones = [
        '11' => ['nombre' => 'Tallarin', 'precio' => 11.00],
        '12' => ['nombre' => 'Cubana', 'precio' => 14.00],
        '13' => ['nombre' => 'Seco de Carne', 'precio' => 12.00],
        '14' => ['nombre' => 'Arroz Tapado', 'precio' => 15.00],
        '15' => ['nombre' => 'Ají de Gallina', 'precio' => 11.00],
        '16' => ['nombre' => 'Estofado', 'precio' => 10.00],
        '17' => ['nombre' => 'Pollo a la Plancha', 'precio' => 10.00],
        '18' => ['nombre' => 'Arroz con Pollo', 'precio' => 10.00],
        '19' => ['nombre' => 'Puré', 'precio' => 12.00],
        '20' => ['nombre' => 'Lomo Saltado', 'precio' => 20.00]
    ];

    $cenaOpciones = [
        '21' => ['nombre' => 'Pizza Americana', 'precio' => 20.00],
        '22' => ['nombre' => 'Pizza con Piña', 'precio' => 22.00],
        '23' => ['nombre' => 'Pan con Huevo', 'precio' => 5.00],
        '24' => ['nombre' => 'Café', 'precio' => 4.50],
        '25' => ['nombre' => 'Chocolate', 'precio' => 5.00],
        '26' => ['nombre' => 'Broster', 'precio' => 8.00],
        '27' => ['nombre' => 'Hamburguesa', 'precio' => 7.00],
        '28' => ['nombre' => 'Caldo de Gallina', 'precio' => 10.00],
        '29' => ['nombre' => 'Salchipapa', 'precio' => 6.00],
        '30' => ['nombre' => 'Té', 'precio' => 3.50]
    ];

    // Inicializar variables de selección y total
    $seleccionados = [];
    $total = 0;
    $IGV = 0.18;

    // Procesar la selección del usuario y mostrar el resumen de compra
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['seleccionados']) && is_array($_POST['seleccionados'])) {
            foreach ($_POST['seleccionados'] as $codigo => $nombre) {
                if (isset($desayunoOpciones[$codigo])) {
                    $seleccionados[] = ['nombre' => $nombre, 'precio' => $desayunoOpciones[$codigo]['precio']];
                } elseif (isset($almuerzoOpciones[$codigo])) {
                    $seleccionados[] = ['nombre' => $nombre, 'precio' => $almuerzoOpciones[$codigo]['precio']];
                } elseif (isset($cenaOpciones[$codigo])) {
                    $seleccionados[] = ['nombre' => $nombre, 'precio' => $cenaOpciones[$codigo]['precio']];
                }
            }
        }

        // Calcular total acumulado y mostrar boleta de ventas
        if (!empty($seleccionados)) {
            echo "<div class='tabla__boletas'>";
            echo "<h2>BOLETA DE VENTAS</h2>";
            echo "<h3>Resumen de Compra:</h3>";
            echo "<table class='boletita'>";
            echo "<tr><th>Nombre</th><th>Precio</th></tr>";
            foreach ($seleccionados as $opcion) {
                echo "<tr><td>{$opcion['nombre']}</td><td>S/. {$opcion['precio']}</td></tr>";
                $total += $opcion['precio'];
            }
            echo "</table>";
            echo "</div>";

            // Mostrar nombre y DNI del cliente
            $nombreCliente = isset($_POST['nombreCliente']) ? $_POST['nombreCliente'] : '';
            $dniCliente = isset($_POST['dniCliente']) ? $_POST['dniCliente'] : '';
            echo "<div class='resultado'>";
            echo "<h3>Datos: </h3>";
            echo "<p>Nombre del Cliente: $nombreCliente</p>";
            echo "<p>DNI del Cliente: $dniCliente</p>";

            $subtotal = $total;
            $igv = $subtotal * $IGV;
            $totalConIGV = $subtotal + $igv;
            echo "<p>SubTotal: S/. " . number_format($subtotal, 2) . "</p>";
            echo "<p>IGV (18%): S/. " . number_format($igv, 2) . "</p>";
            echo "<p>Total a Pagar: S/. " . number_format($totalConIGV, 2) . "</p>";
            echo "<p>¡GRACIAS POR TU COMPRA!</p>";
            echo "</div>";
        }
    }
    ?>

    <h1 class="tituloprincipal">RESTAURANTE S.A</h1>
    <form method="post" class="table__meals">
        <?php
            mostrarMenu('Desayuno', $desayunoOpciones);
            mostrarMenu('Almuerzo', $almuerzoOpciones);
            mostrarMenu('Cena', $cenaOpciones);
            ?>
        <div class="formita">
            <label for="nombreCliente">Nombre del Cliente:</label><br>
            <input type="text" id="nombreCliente" name="nombreCliente" placeholder="Ingrese su nombre" required><br>
            <label for="dniCliente">DNI del Cliente:</label><br>
            <input type="text" id="dniCliente" name="dniCliente" placeholder="Ingrese su DNI" required>
            <input type="submit" name="submit" value="Agregar">
        </div>
    </form>
</body>
</html>